export class Message {
    senderEmail: string;
    time: string;
    replymessage: string;
    chat: any;

    constructor() {

    }
}
