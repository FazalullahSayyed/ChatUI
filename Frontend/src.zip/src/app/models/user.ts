export class User {
    userName:string;

    constructor(){}
}
